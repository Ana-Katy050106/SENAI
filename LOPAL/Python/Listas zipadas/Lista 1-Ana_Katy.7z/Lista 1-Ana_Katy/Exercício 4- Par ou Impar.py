#-*- coding: UTF-8 -*-

print("Olá usuário, você irá ler um número e me dizer se ele é par ou impar")

num = int(input("Digite um número: "))

if num % 2 == 0:
    print("O número é par!")

else:
    print("O número é impar!")
