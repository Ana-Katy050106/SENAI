#-*- coding: UTF-8 -*-

print("Olá usuário, você irá ler um número e me dizer se ele é múltiplo por 3 ou não")

num = int(input("Digite um número: "))

if num % 3 == 0:
    print("O número é múltiplo de 3!")

else:
    print("O número é não é múltiplo de 3!")
