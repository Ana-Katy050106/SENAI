#-*- coding: UTF-8 -*-

print("Olá usuário, digite um número e eu lhe direi se é divisivel por 3 ou não")

num = int(input("Digite um número: "))

if num % 3 == 0:
    print("O número é divisivel por 3!")

else:
    print("O número não é divisivel por 3!")
